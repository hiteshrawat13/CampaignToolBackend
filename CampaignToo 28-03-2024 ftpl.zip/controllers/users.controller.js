
const jwt=require("jsonwebtoken")
const bcrypt = require('bcryptjs');

const {userModel}  = require("../models/users.js")



exports.login= async (req,res)=>{
   

    try {
        const { empid , password } = req.body;

        const user = await userModel.findOne({
            where: {empid}
        });
        if (!user) {
            return res.status(404).json('User not found');
        }

        if(user.status === false){
            return res.status(401).json('User is disabled');
        }

        // Verify password
        const passwordValid = password ===user.password;
        if (!passwordValid) {
            return res.status(404).json('Incorrect id and password combination');
        }


        // Authenticate user with jwt
        const token = jwt.sign({ id: user.empid }, process.env.JWT_SECRET, {
            expiresIn: "1000"
        });
   
        res.status(200).send({
            id: user.empid,
            name: user.name,
            accessToken: token,
        });
    } catch (err) {
        return res.status(500).send('Sign in error');
    }

}



exports.getUsers = async (req, res) => {

    const users = await userModel.findAll();

    return  res.status(200).json(users);

}



exports.createUser = async (req, res) => {
    userModel.create({
        name:req.body.name,	
        empid:req.body.empid,	
        password:req.body.password,	
        role:req.body.role,
        status:req.body.status
    })
    .then((result) => {
        return res.json({
              message: "User created successfully!",
        });
    })
    .catch((error) => {
        console.log(error);
        return res.json({
              message: `Unable to create a User! ${error}`,
        });
    });
}



exports.editUser = async (req, res) => {

    try{
        const user = await userModel.findOne({
            where: {
                empid: req.body.empid
            }
          })
          
          await user.update({ 
            name:req.body.name,	
        empid:req.body.empid,	
        password:req.body.password,	
        role:req.body.role,
        status:req.body.status
           });
          return res.json({
            message: "user updated successfully!",
            });
    }catch(error){
        return res.json({
            message: `Unable to update a user! ${error}`,
         });
    }
   
}

exports.deleteUser = async (req, res) => {

    try{

     await  userModel.destroy({
            where: {
                empid:req.body.empid
            }
          });
          
          return res.json({
            message: "user deleted successfully!",
            });

    }catch(error){
        return res.json({
            message: `Unable to delete a user! ${error}`,
         });
    }
   
}


exports.disableUser = async (req, res) => {

    try{
        const user = await userModel.findOne({
            where: {
                empid:req.body.empid
            }
          })
          
          await user.update({  status:req.body.status });
          return res.json({
            message: "user status updated successfully!",
            });
    }catch(error){
        return res.json({
            message: `Unable to disable a user! ${error}`,
         });
    }
   
}



