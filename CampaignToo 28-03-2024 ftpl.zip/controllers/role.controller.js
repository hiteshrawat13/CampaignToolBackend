const {userRole}  = require("../models/userRole.js");
const {rolePermissions}  = require("../models/rolePermissions.js");
const {modules}  = require("../models/modules.js");


//Create the new Role

exports.roleCreate = async (req, res, next) => {
  try {
    const  name  = req.body.name;

    const existingRole= await userRole.findOne({
      where: {
        name: name
      }
    });

    if (existingRole) {
      return res.status(400).json({ message: 'Role already exists' });
    }
   
    

    const newRole = await userRole.create({
      name:name
    });

    res.status(201).json({ message: 'Role created successfully', role: newRole });
  } catch (error) {
    // Handle errors
    console.error('Error during role creation:', error);
    res.status(500).json({ message: 'Internal server error',error });
  }
};

  
  // DELETE THE Role

exports.editRole = async (req, res) => {

  try{
      // const role = await rolePermissions.findAll({
      //     where: {
      //       role_id: req.body.roleId
      //     }
      //   })


      // console.log(req.body);


      for (const element of req.body.arr) {
           
          let [record, created] = await rolePermissions.findOrCreate({
            where:{
              role_id:req.body.roleID,
              module_id:element.moduleId,
            },
            defaults: { 
              create_p:element.create,	
              read_p:element.read,	
              update_p:element.update,
              delete_p:element.delete,
              role_id:req.body.roleID,
              module_id:element.moduleId,
              module_name:element.moduleName,
            }
          });

          if (!created) {
            // If record exists, update it
            await  record.update({ 
              create_p:element.create,	
              read_p:element.read,	
              update_p:element.update,
              delete_p:element.delete,              
             });
          }
              
        };


        return res.json({
          message: "Role updated successfully!",
          });
  }catch(error){
      return res.json({
          message: `Unable to update a Role! ${error}`,
       });
  }
 
}


  
  // DELETE THE Role
  
  exports.deleteRole = async (req, res, next) => {
    try {
      const  id  = req.body.id;
  
      const role = await userRole.findByPk(id);
      if (!role) {
        return res.status(404).json({ message: 'Role not found' });
      }
  
      // Delete the user
      await role.destroy();
  
      res.status(200).json({ message: 'Role has been deleted.' });
    } catch (err) {
      next(err);
    }
  };
  
  //GET ALL THE ROLE FORM DB
  exports.getAllRoles = async (req, res, next) => {
    try {
      // Fetch all leads
      const roles = await userRole.findAll();
      
      // If there are no leads, return 404
      if (roles.length === 0) {
        return res.status(404).json({ message: 'No role found' });
      }
      
      // If leads are found, return them
      res.status(200).json({ roles });
    } catch (err) {
      next(err);
    }
  };


    //GET ALL THE ROLE Permissions DB
    exports.getRolePermission = async (req, res, next) => {
      try {
        // Fetch all leads
        const roles = await rolePermissions.findAll(
          {
            where:{
              role_id:req.body.roleID
            }
          }
        );
        
        // If there are no leads, return 404
        if (roles.length === 0) {
          return res.status(404).json({ message: 'No role found' });
        }
        
        // If leads are found, return them
        res.status(200).json({ roles });
      } catch (err) {
        next(err);
      }
    };
  


// //////////////////////////////////// Modules /////////////////////////////////

//Create the new Module

exports.createModule = async (req, res, next) => {
  try {
    const  name  = req.body.name;

    const existingModule= await modules.findOne({
      where: {
        name: name
      }
    });

    if (existingModule) {
      return res.status(400).json({ message: 'Role already exists' });
    }
   
    

    const newModule = await modules.create({
      name:name
    });

    res.status(201).json({ message: 'Module created successfully', module: newModule });
  } catch (error) {
    // Handle errors
    console.error('Error during module creation:', error);
    res.status(500).json({ message: 'Internal server error',error });
  }
};

exports.deleteModule = async (req, res, next) => {
  try {
    const id  = req.body.id;

    const module = await modules.findByPk(id);
    if (!module) {
      return res.status(404).json({ message: 'module not found' });
    }

    // Delete the module
    await module.destroy();

    res.status(200).json({ message: 'module has been deleted.' });
  } catch (err) {
    next(err);
  }
};

exports.getAllModules = async (req, res, next) => {
  try {
    // Fetch all leads
    const module = await modules.findAll();
    
    // If there are no leads, return 404
    if (module.length === 0) {
      return res.status(404).json({ message: 'No Module found' });
    }
    
    // If leads are found, return them
    res.status(200).json({ module });
  } catch (err) {
    next(err);
  }
};
